import { TestBed, inject } from '@angular/core/testing';

import { SvInterceptorService } from './interceptor.service';
import { ApiService, NotificationService, MembershipService } from 'app/areas/admin/core/adminservice-index';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CookieModule } from 'ngx-cookie';
import { ErrorHandlerService } from 'library-core/services/error-handler/error-handler.service';
import { ToastrModule } from 'ngx-toastr';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from 'user-services/common/common.service';
import { LanguageService, CategoryService } from 'user-core/userservice-index';
import { LoaderService } from 'shared-services/loader/loader.service';

describe('SvInterceptorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        CookieModule.forRoot(),
        ToastrModule.forRoot(),
        TranslateModule.forRoot(),
        RouterTestingModule
      ],
      providers: [
        SvInterceptorService,
        ApiService,
        ErrorHandlerService,
        NotificationService,
        MembershipService,
        CommonService,
        LanguageService,
        LoaderService,
        CategoryService
      ]
    });
  });

  it('should be created', inject([SvInterceptorService], (service: SvInterceptorService) => {
    expect(service).toBeTruthy();
  }));
});
