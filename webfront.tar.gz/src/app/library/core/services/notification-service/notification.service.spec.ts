import { TestBed, inject } from '@angular/core/testing';

import { NotificationService } from './notification.service';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { TranslateModule } from '@ngx-translate/core';
describe('NotificationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ToastrModule.forRoot(),
        TranslateModule.forRoot(),
      ],
      providers: [NotificationService]
    });
  });

  it('should be created', inject([NotificationService], (service: NotificationService) => {
    expect(service).toBeTruthy();
  }));
  it('should be Success with value', inject([NotificationService], (service: NotificationService) => {
    expect(service.Success({ message: 'Test Message', title: 'Test Title' })).toBeTruthy();
  }));
  it('should be Success with First parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Success({ message: null, title: 'Test Title' })).toBeFalsy();
  }));
  // it('should be Success with second parameter null', inject([NotificationService], (service: NotificationService) => {
  //   expect(service.Success({ message: 'Test Message', title: null })).toBeFalsy();
  // }));
  it('should be Success with both parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Success({ message: null, title: null })).toBeFalsy();
  }));
  it('should be Success with first parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Success({ message: '', title: 'Test Title' })).toBeFalsy();
  }));
  it('should be Success with second parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Success({ message: 'Test Message', title: '' })).toBeTruthy();
  }));
  it('should be Success with both parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Success({ message: '', title: '' })).toBeFalsy();
  }));
  // Test Case for Error function
  it('should be Error with value', inject([NotificationService], (service: NotificationService) => {
    expect(service.Error({ message: 'Test Message', title: 'Test Title' })).toBeTruthy();
  }));
  it('should be Error with First parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Error({ message: null, title: 'Test Title' })).toBeFalsy();
  }));
  // it('should be Error with second parameter null', inject([NotificationService], (service: NotificationService) => {
  //   expect(service.Error({ message: 'Test Message', title: null })).toBeFalsy();
  // }));
  it('should be Error with both parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Error({ message: null, title: null })).toBeFalsy();
  }));
  it('should be Error with first parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Error({ message: '', title: 'Test Title' })).toBeFalsy();
  }));
  it('should be Error with second parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Error({ message: 'Test Message', title: '' })).toBeTruthy();
  }));
  it('should be Error with both parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Error({ message: '', title: '' })).toBeFalsy();
  }));
  //  // Test Case for Warning function
   it('should be Warning with value', inject([NotificationService], (service: NotificationService) => {
    expect(service.Warning({ message: 'Test Message', title: 'Test Title' })).toBeTruthy();
  }));
  it('should be Warning with First parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Warning({ message: null, title: 'Test Title' })).toBeFalsy();
  }));
  // it('should be Warning with second parameter null', inject([NotificationService], (service: NotificationService) => {
  //   expect(service.Warning({ message: 'Test Message', title: null })).toBeFalsy();
  // }));
  it('should be Warning with both parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Warning({ message: null, title: null })).toBeFalsy();
  }));
  it('should be Warning with first parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Warning({ message: '', title: 'Test Title' })).toBeFalsy();
  }));
  it('should be Warning with second parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Warning({ message: 'Test Message', title: '' })).toBeTruthy();
  }));
  it('should be Warning with both parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Warning({ message: '', title: '' })).toBeFalsy();
  }));
  // Test Case for Info
  it('should be Info with value', inject([NotificationService], (service: NotificationService) => {
    expect(service.Info({ message: 'Test Message', title: 'Test Title' })).toBeTruthy();
  }));
  it('should be Info with First parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Info({ message: null, title: 'Test Title' })).toBeFalsy();
  }));
  // it('should be Info with second parameter null', inject([NotificationService], (service: NotificationService) => {
  //   expect(service.Info({ message: 'Test Message', title: null })).toBeFalsy();
  // }));
  it('should be Info with both parameter null', inject([NotificationService], (service: NotificationService) => {
    expect(service.Info({ message: null, title: null })).toBeFalsy();
  }));
  it('should be Info with first parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Info({ message: '', title: 'Test Title' })).toBeFalsy();
  }));
  it('should be Info with second parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Info({ message: 'Test Message', title: '' })).toBeTruthy();
  }));
  it('should be Info with both parameter empty', inject([NotificationService], (service: NotificationService) => {
    expect(service.Info({ message: '', title: '' })).toBeFalsy();
  }));
});
