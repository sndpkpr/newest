import { NgModule } from '@angular/core';
import { AuthRoutingModule } from './auth-routing.module';
import { AuthComponent } from './auth.component';
import { LoginComponent } from './components/login/login.component';
import { SharedModule } from '../../library/shared/shared.module';
import { NbAuthModule, NbAuthService } from '@nebular/auth';

@NgModule({
  declarations: [AuthComponent, LoginComponent],
  imports: [
    AuthRoutingModule,
    SharedModule,
    NbAuthModule
  ],
  providers: []
})
export class AuthModule { }
