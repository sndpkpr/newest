export class CategoryModel {
    CategoryFor?: string;
    CategoryName?: string;
    CategoryType?: number;
    CreatedDate?: string;
    ID?: string;
    IsDeleted?: boolean;
    KeyID?: number;
    ModifiedDate?: string;
    ParentCategory?: string;
}

export class GroupModel {
    CreatedDate?: string;
    GroupId?: string;
    ID?: string;
    IsDeleted?: false;
    UserId?: string;
    GroupDescription?: string;
    GroupName?: string;
    IsFavorite?: boolean;
    IsJoined?: boolean;

}

export class DiscussionModel {
    CreatedDate?: string;
    GroupId?: string;
    ID?: string;
    IsDeleted?: false;
    UserId?: string;
    GroupDescription?: string;
    GroupName?: string;
    IsFavorite?: boolean;
    IsJoined?: boolean;

}

export class EventModel {
    ID?: string;
    EventDescription?: string;
    EventTitle?: string;
    IsDeleted?: false;
    UserId?: string;
    FileName?: string;
    IsPublish?: boolean;
}
