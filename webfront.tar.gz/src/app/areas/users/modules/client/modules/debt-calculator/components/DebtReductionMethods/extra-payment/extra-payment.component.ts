import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sndp-extra-payment',
  templateUrl: './extra-payment.component.html',
  styleUrls: ['./extra-payment.component.css']
})
export class ExtraPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
