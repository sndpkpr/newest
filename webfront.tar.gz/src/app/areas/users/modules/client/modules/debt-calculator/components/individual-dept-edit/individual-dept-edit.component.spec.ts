import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualDeptEditComponent } from './individual-dept-edit.component';

describe('IndividualDeptEditComponent', () => {
  let component: IndividualDeptEditComponent;
  let fixture: ComponentFixture<IndividualDeptEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualDeptEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualDeptEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
