import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { CookieService } from 'ngx-cookie';
import { ApiService } from '../api-service/api.service';
import { CoreAPIURLs } from '../../config/constants';
import { IMembershipModel, IMembershipRepoModel } from '../../../shared/viewmodels/membership-model';

import { map } from 'rxjs/operators';
// import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
// import { LanguageService } from 'user-core/userservice-index';

@Injectable({
  providedIn: 'root'
})
export class MembershipService {
  private token: string;
  membershipmodel: IMembershipModel = {};
  membershipModelRepo: IMembershipRepoModel = {};
  private roleId = '';
  IsNZPopupClosed: boolean;
  // NZcookieObj: { Date: Date, IsNZPopupClosed: boolean };
  constructor(private http: HttpClient, private apiservice: ApiService, private cookie: CookieService, private router: Router) { }

  login(body: {}) {
    // logic for login
    return this.apiservice.postData(CoreAPIURLs.loginUrl, body, null)
      .pipe(map((res: any) => {
        if (res && res.body.token) {
          return res.body.token;
          // return this.getUserByName('api/Account/GetuserDetailsByUserName',body);
        }
      }));
  }

  logout() {
    this.removeCredentials();
    this.router.navigate(['/auth/login']);
  }

  getUserByName(body, lang) {
    return this.apiservice.postData<IMembershipModel>(CoreAPIURLs.getuserDetailsByUserNameUrl, {
      token: body,
      Language: lang
    }, null).pipe(map((res) => {
      this.token = body;
      // this.membershipmodel.IPCountry = res.body.data.IPCountry;
      // this.membershipmodel.Id = res.body.data.ID;
      // this.membershipmodel.Username = res.body.data.Username;
      // this.membershipmodel.IsLocked = res.body.data.IsLocked;
      // this.membershipmodel.IsDeleted = res.body.data.IsDeleted;
      // this.membershipmodel.IsDeactivated = res.body.data.IsDeactivated;
      // this.membershipmodel.FileName = res.body.data.FileName;
      // this.membershipmodel.ThumbnailFileName = res.body.data.ThumbnailFileName;
      // this.membershipmodel.FullName = res.body.data.FullName;
      // this.membershipmodel.Email = res.body.data.Email;
      // this.membershipmodel.UserRole = res.body.data.KeyID;
      // this.membershipmodel.RoleIds = res.body.data.RoleIds;
      // this.membershipmodel.FullNameEnglish = res.body.data.FullNameEnglish;
      // this.membershipmodel.FirstName = res.body.data.FirstName;
      // this.membershipmodel.FirstNameEnglish = res.body.data.FirstNameEnglish;
      // this.membershipmodel.IsProfileFilled = res.body.data.IsProfileFilled;
      // this.membershipmodel.CountryKeyId = res.body.data.Country !== null ? res.body.data.Country.KeyID : 0;
      // this.membershipmodel.LastName = res.body.data.LastName;
      // this.membershipmodel.LastNameEnglish = res.body.data.LastNameEnglish;
      // this.membershipmodel.Country = { KeyID: res.body.data.Country !== null ? res.body.data.Country.KeyID : 0 };
      // this.membershipmodel.FacilitatorCompanyId = res.body.data.SubAccountCompanyId;
      // this.membershipmodel.CountryName = res.body.data.Country !== null ? res.body.data.Country.CountryName : '';
      // this.membershipmodel.CompanyCountryKeyID = res.body.data.CompanyCountryKeyID;
      // this.membershipmodel.CompanyCountryName = res.body.data.CompanyCountryName;
      // this.membershipmodel.CountryID = res.body.data.Country.ID;
      // this.membershipmodel.LanguageCode = res.body.data.LanguageCode;


      // this.membershipModelRepo.IPCountry = res.body.data.IPCountry;
      // this.membershipModelRepo.id = res.body.data.ID;
      // this.membershipModelRepo.username = res.body.data.Username;
      // this.membershipModelRepo.IsLocked = res.body.data.IsLocked;
      // this.membershipModelRepo.IsDeleted = res.body.data.IsDeleted;
      // this.membershipModelRepo.IsDeactivated = res.body.data.IsDeactivated;
      // this.membershipModelRepo.FileName = res.body.data.FileName;
      // this.membershipModelRepo.ThumbnailFileName = res.body.data.ThumbnailFileName;
      // this.membershipModelRepo.fullName = res.body.data.FullName;
      // this.membershipModelRepo.email = res.body.data.Email;
      // this.membershipModelRepo.UserRole = res.body.data.KeyID;
      // this.membershipModelRepo.RoleIds = res.body.data.RoleIds;
      // this.membershipModelRepo.fullNameEnglish = res.body.data.FullNameEnglish;
      // this.membershipModelRepo.FirstName = res.body.data.FirstName;
      // this.membershipModelRepo.FirstNameEnglish = res.body.data.FirstNameEnglish;
      // this.membershipModelRepo.IsProfileFilled = res.body.data.IsProfileFilled;
      // this.membershipModelRepo.CountryKeyId = res.body.data.Country !== null ? res.body.data.Country.KeyID : 0;
      // this.membershipModelRepo.LastName = res.body.data.LastName;
      // this.membershipModelRepo.LastNameEnglish = res.body.data.LastNameEnglish;
      // this.membershipModelRepo.Country = {
      //   KeyID: res.body.data.Country !== null ?
      //     res.body.data.Country.KeyID : 0, CountryID: res.body.data.Country.ID
      // };
      // this.membershipModelRepo.FacilitatorCompanyId = res.body.data.SubAccountCompanyId;
      // this.membershipModelRepo.CountryName = res.body.data.Country !== null ? res.body.data.Country.CountryName : '';
      // this.membershipModelRepo.CompanyCountryKeyID = res.body.data.CompanyCountryKeyID;
      // this.membershipModelRepo.CompanyCountryName = res.body.data.CompanyCountryName;
      // this.membershipModelRepo.LocationName = res.body.data.LocationName ? res.body.data.LocationName : null;
      // this.membershipModelRepo.PhoneNumber = res.body.data.PhoneNumber ? res.body.data.PhoneNumber : null;
      // this.membershipModelRepo.ServcorpLocationId = res.body.data.ServcorpLocationId != null ? res.body.data.ServcorpLocationId : null;
      // this.membershipmodel.ServcorpLocationId = res.body.data.ServcorpLocationId != null ? res.body.data.ServcorpLocationId : null;
      // this.membershipmodel.CountryID = res.body.data.Country.ID;
      // this.IsNZPopupClosed = res.body.data.IsNZPopupClosed == null ? true : res.body.data.IsNZPopupClosed ;
      // this.NZcookieObj = {Date: new Date(), IsNZPopupClosed: this.IsNZPopupClosed};

      this.setUserCookie(this.membershipmodel);
      this.setUserCookieRepo(this.membershipModelRepo);
      this.cookie.put('language', this.membershipmodel.LanguageCode);
      // this.cookie.putObject('NZcookieObj', this.NZcookieObj);
      return res.status;
      // this.membershipmodel.token = res.token;
    }));

  }

  isLoggedIn(): boolean {
    return this.getToken() ? true : false;
  }

  getToken(): string {
    const token = this.cookie.get('token') ? this.cookie.get('token') : null;
    // const token = localStorage.getItem('token') ? localStorage.getItem('token') : null;
    return token;
  }

  private setUserCookie(data: IMembershipModel) {
    this.removeCredentials();
    let lang = '';
    if (this.cookie.get('language')) {
      lang = this.cookie.get('language');
    } else {
      /**Set language according to timezone if language not found in cookies */
      lang = 'en-US';
    }
    this.cookie.putObject('lang', lang);
    // this.cookie.put('token', this.token);
    this.cookie.putObject('token', this.token);
    this.cookie.put('UserRole', data.UserRole);
    this.cookie.putObject('userdetails', data);
    localStorage.setItem('token', this.token);
  }
  private setUserCookieRepo(data: IMembershipRepoModel) {
    this.cookie.putObject('repository', { loggedUser: data });
  }

  setCookie(key: string, value: string) {
    this.cookie.put(key, value);
  }

  getCookie(key: string) {
    return this.cookie.get('key');
  }

  getUserDetails(key: string) {
    const userDetails = this.cookie.getObject('userdetails');
    if (userDetails === undefined) { return ''; } else { return userDetails[key]; }
  }

  getCookieObject(key: string): IMembershipModel {
    const obj = this.cookie.getObject(key);
    if (obj === undefined) { return {}; } else {
      return obj;
    }
  }

  getCurrentUserObject(): IMembershipModel {
    const userDetails = this.cookie.getObject('userdetails');
    if (userDetails === undefined) { return {}; } else {
      return userDetails;
    }
  }

  getAllCookies(): {} {
    return this.cookie.getAll();
  }

  removeCredentials() {
    this.cookie.remove('userdetails');
    this.cookie.remove('token');
    this.cookie.remove('repository');
    this.cookie.remove('IsPopupActive');
    // this.cookie.remove('NZcookieObj');
    localStorage.clear();
  }

  removeIsEditFromDashboard() {
    this.cookie.remove('IsEditByDashboard');
  }

  public setLocalStorage(key: string, value: string): void {
    localStorage.setItem(key, value);
  }

  getLocalStorage(key: string) {
    return localStorage.getItem(key);
  }
}
