// library shared services
