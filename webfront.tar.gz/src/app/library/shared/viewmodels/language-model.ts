export class LanguageModel {
    value: string;
    Text: string;
}
export class DropDownModel {
    value: number;
    label: string;
}
