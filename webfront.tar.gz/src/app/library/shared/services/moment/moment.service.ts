import { Injectable } from '@angular/core';
import moment from 'moment-timezone';

@Injectable({
  providedIn: 'root'
})
export class MomentService {

  constructor() { }

  momentUTCtoLocalForPayOff(date, format) {
    if (date === '' || date === undefined) {
      return;
    }
    try {
      return moment(date).format('MMM Do YYYY');
    } catch (e) {
      return date;
    }
  }
}
