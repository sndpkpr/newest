// export const InitialData = [{
//     description: 'Stafford 1',
//     balance: 40000.00,
//     minimumPaymentPercent: 0.000,
//     minimumPaymentAmount: 495.00,
//     currentPayment: 495.00,
//     interestRate: 4.450,
//     paymentDueDay: 10,
//     compoundFrequency: 'Monthly'
// }];
export const InitialData = {
    description: 'Test Data',
    balance: 40000.00,
    minimumPaymentPercent: 0.000,
    minimumPaymentAmount: 495.00,
    currentPayment: 495.00,
    interestRate: 4.450,
    paymentDueDay: 10,
    compoundFrequency: 'Monthly'
};
