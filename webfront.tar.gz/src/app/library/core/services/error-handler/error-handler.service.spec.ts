import { TestBed, inject } from '@angular/core/testing';

import { ErrorHandlerService } from './error-handler.service';
import { NotificationService } from './../notification-service/notification.service';
import { ToastrModule } from 'ngx-toastr';
import { TranslateModule } from '@ngx-translate/core';
import { log } from 'util';
import { CookieModule } from 'ngx-cookie';
import { RouterTestingModule } from '@angular/router/testing';


describe('ErrorHandlerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ToastrModule.forRoot(),
        TranslateModule.forRoot(),
        CookieModule.forRoot(),
        RouterTestingModule
      ],
      providers: [ErrorHandlerService, NotificationService]
    });
  });
  it('should be created', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service).toBeTruthy();
  }));
  it('handleError is defined', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError).not.toBeUndefined();
  }));
  it('should be created handleError with  status code 200', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(200)).toBeFalsy();
  }));
  it('should be created handleError  with  status code 201', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(201)).toBeFalsy();
  }));
  it('should be created handleError  with  status code 400', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(400)).toBeUndefined();
  }));
  it('should be created handleError  with  status code 401', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(401)).toBeUndefined();
  }));
  it('should be created handleError  with  status code 403', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(403)).toBeUndefined();
  }));
  it('should be created handleError  with  status code 404', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(404)).toBeUndefined();
  }));
  it('should be created handleError  with  status code 500', inject([ErrorHandlerService], (service: ErrorHandlerService) => {
    expect(service.handleError(500)).toBeUndefined();
  }));
});
