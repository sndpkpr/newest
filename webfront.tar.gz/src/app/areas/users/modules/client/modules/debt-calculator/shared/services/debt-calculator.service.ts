import { Injectable } from '@angular/core';
import { DebtCalculator } from '../constants/apiURLs';
import { ApiService } from '@library-core/services/api-service/api.service';
import { map } from 'rxjs/operators';
import { EmptyObservable } from 'rxjs/observable/EmptyObservable';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DebtCalculatorService {

  constructor(private apiService: ApiService) { }

  currentPayback(body): any {
    if (body.length) {
      return this.apiService.postData(DebtCalculator.currentPayback, body, null);
    } else {

    }
  }

  // createConfirm(body): any {
  //   if (this.acceptOrReject(body)) {
  //     return this.apiService.postData(DebtCalculator.createConfirm, body.data, null);
  //   } else {
  //     console.log('ewewewqe');
  //     console.log(new Observable<{}>());
  //     return new Observable<{}>();
  //   }
  // }
  createConfirm(body): any {
    return this.apiService.postData(DebtCalculator.createConfirm, body, null);
  }

  acceptOrReject(body): any {
    for (const [key, value] of Object.entries(body)) {
      if (!value && key !== ('minimumPaymentPercent' || 'minimumPaymentAmount')) {
        return false;
      }
    }
    return true;
  }
}
