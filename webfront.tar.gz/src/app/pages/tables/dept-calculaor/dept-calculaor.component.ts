import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { SmartTableService } from '../../../@core/data/smart-table.service';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-dept-calculaor',
  templateUrl: './dept-calculaor.component.html',
  styles: [`
    nb-card {
      transform: translate3d(0, 0, 0);
    }
  `],
})
export class DeptCalculaorComponent {

  /**
   * form
   */
  deptCalcForm: FormGroup;
  /**
   * form
   */

  list = [
    { value: 'Continuous', title: 'Continuous' },
    { value: 'Daily', title: 'Daily' },
    { value: 'Weekly', title: 'Weekly' },
    { value: 'Twice Monthly', title: 'Twice Monthly' },
    { value: 'Every 4 Weeks', title: 'Every 4 Weeks' },
    { value: 'Monthly', title: 'Monthly' },
    { value: 'Bimonthy', title: 'Bimonthy' },
    { value: 'Quarterly', title: 'Quarterly' },
    { value: 'Every 4 Months', title: 'Every 4 Months' },
    { value: 'Semiannually', title: 'Semiannually' },
    { value: 'Annually', title: 'Annually' },
    { value: 'Exact', title: 'Exact' }
  ];

  settings = {
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      // debtDescription: {
      //   title: 'Debt Description',
      //   type: 'string',
      // },
      // debtBalance: {
      //   title: 'Debt Balance',
      //   type: 'number',
      // },
      // minimumPaymentPct: {
      //   title: 'Minimum Payment Pct',
      //   type: 'number',
      // },
      // minimumPaymentAmount: {
      //   title: 'Minimum Payment Amount',
      //   type: 'number',
      // },
      // currentPayment: {
      //   title: 'Current Payment',
      //   type: 'number',
      // },
      // interestRate: {
      //   title: 'Interest Rate',
      //   type: 'number',
      // },
      // dayDue: {
      //   title: 'Day Due (1-31)',
      //   type: 'number',
      // },
      // compounding: {
      //   title: 'Compounding',
      //   type: 'number',
      // },
      // priority: {
      //   title: 'Priority',
      //   type: 'number',
      // }
      description: {
        title: 'Debt Description',
        type: 'string',
      },
      balance: {
        title: 'Debt Balance',
        type: 'number',
        valuePrepareFunction: (value) => {
          return value === 'Total' ? value : Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
        }
      },
      minimumPaymentPercent: {
        title: 'Minimum Payment Pct',
        type: 'number',
      },
      minimumPaymentAmount: {
        title: 'Minimum Payment Amount',
        type: 'number',
      },
      currentPayment: {
        title: 'Current Payment',
        type: 'number',
      },
      interestRate: {
        title: 'Interest Rate',
        type: 'number',
      },
      paymentDueDay: {
        title: 'Day Due (1-31)',
        type: 'number',
      },
      compoundFrequency: {
        title: 'Compounding',
        type: 'html',
        editor: {
          type: 'list',
          config: {
            list: this.list,
          },
        }
      }
      // priority: {
      //   title: 'Priority',
      //   type: 'number',
      // }
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(private service: SmartTableService,
    private fb: FormBuilder) {
    /**
     * IF loaded privously uncomment and see
     */
    // const data = this.service.getData();
    // this.source.load(data);
    this.createForm();
  }

  private createForm(): void {
    this.deptCalcForm = this.fb.group({
      description: ['', [Validators.required]],
      compoundFrequency: [''],
      paymentDueDay: ['', [Validators.required]],
      minimumPaymentPercent: [''],
      balance: [''],
      interestRate: ['', [Validators.required]],
      currentPayment: ['', [Validators.required]],
      minimumPaymentAmount: ['', [Validators.required]],
    });
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onRowSelect(event): void {
    this.setValueDeptCalcForm(event);
  }
  private setValueDeptCalcForm({ data }): void {
    this.deptCalcForm.patchValue(data);
  }

  getAll(): void {
    console.log(this.source);
  }
}
