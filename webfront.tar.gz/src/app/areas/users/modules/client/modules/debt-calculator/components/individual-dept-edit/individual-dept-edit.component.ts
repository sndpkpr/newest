import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { PLACEHOLDERS } from '../../shared/constants/constant-index';

@Component({
  selector: 'sndp-dept-edit',
  templateUrl: './individual-dept-edit.component.html',
  styleUrls: ['./individual-dept-edit.component.css']
})
export class IndividualDeptEditComponent implements OnInit {

  constructor(private fb: FormBuilder) { }

  deptCalcForm: FormGroup;
  @Input() Dept;

  ngOnInit() {
    this.createForm();
  }

  private createForm(): void {
    this.deptCalcForm = this.fb.group({
      description: [this.Dept.description, [Validators.required]],
      compoundFrequency: [this.Dept.compoundFrequency],
      paymentDueDay: [this.Dept.paymentDueDay, [Validators.required]],
      minimumPaymentPercent: [this.Dept.minimumPaymentPercent],
      balance: [this.Dept.balance],
      interestRate: [this.Dept.interestRate, [Validators.required]],
      currentPayment: [this.Dept.currentPayment, [Validators.required]],
      minimumPaymentAmount: [this.Dept.minimumPaymentAmount, [Validators.required]],
    });
  }

  public keypressEvent(event): boolean {
    if (PLACEHOLDERS.indexOf(event.target.placeholder) > -1) {
      if (event.charCode === 46 || (event.charCode > 47 && event.charCode < 58)) {
        return true;
      }
      return false;
    }
    return true;
  }

}
