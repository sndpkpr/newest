import { Component, OnInit, Input } from '@angular/core';
import { MomentService } from '@library-shared/services/moment/moment.service';

@Component({
  selector: 'app-payback-table',
  templateUrl: './payback-table.component.html',
  styles: [`nb-card {  transform: translate3d(0, 0, 0); }`]
})
export class PaybackTableComponent implements OnInit {

  constructor(private momentService: MomentService) { }

  @Input()
  public Source;
  @Input()
  public CurrentPayback;

  paymentOptionDefault = 'Scheduled Amount';
  paymentOption = ['Scheduled Amount', 'Minimum Amount'];

  currentPaymentsDefault = { description: 'All Debts' };
  currentTheme: string;

  ngOnInit() {
  }

  public momentUTCtoLocal(date, format) {
    return this.momentService.momentUTCtoLocalForPayOff(date, format);
  }

  public currentPaymentsChange(val): void {
    this.currentPaymentsDefault = val;
  }

  public paymentOptionChange(val): void {
    this.paymentOptionDefault = val;
  }

}
