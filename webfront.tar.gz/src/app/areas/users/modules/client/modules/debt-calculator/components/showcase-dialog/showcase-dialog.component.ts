import { Component, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { NbDialogRef } from '@nebular/theme';
import { PLACEHOLDERS } from '../../shared/constants/constant-index';
import { AddDebt } from '../../shared/view-models/add-debt';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { LIST } from '../../shared/constants/constant-index';
import { DebtCalculatorService } from '../../shared/services/debt-calculator.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-showcase-dialog',
  templateUrl: 'showcase-dialog.component.html',
  styleUrls: ['showcase-dialog.component.scss'],
})
export class ShowcaseDialogComponent implements OnInit {

  service: Subscription;
  deptCalcForm: FormGroup;
  list = [];
  @Input() title: AddDebt;

  constructor(private fb: FormBuilder,
    protected ref: NbDialogRef<ShowcaseDialogComponent>,
    private debtCalculatorService: DebtCalculatorService) { }

  ngOnInit() {
    this.list = LIST;
    (this.title) ? this.createForm(this.title) : this.createForm1();
  }

  private createForm(dept): void {
    this.deptCalcForm = this.fb.group({
      description: [dept.description || '', [Validators.required]],
      compoundFrequency: [dept.compoundFrequency || '', [Validators.required]],
      paymentDueDay: [dept.paymentDueDay || '', [Validators.required]],
      minimumPaymentPercent: [dept.minimumPaymentPercent || '0', [Validators.required]],
      balance: [dept.balance || '', [Validators.required]],
      interestRate: [dept.interestRate || '', [Validators.required]],
      currentPayment: [dept.currentPayment || '', [Validators.required]],
      minimumPaymentAmount: [dept.minimumPaymentAmount || '', [Validators.required]],
    });
  }

  private createForm1(): void {
    this.deptCalcForm = this.fb.group({
      description: ['', [Validators.required]],
      compoundFrequency: ['', [Validators.required]],
      paymentDueDay: ['', [Validators.required]],
      minimumPaymentPercent: ['', [Validators.required]],
      balance: ['', [Validators.required]],
      interestRate: ['', [Validators.required]],
      currentPayment: ['', [Validators.required]],
      minimumPaymentAmount: ['', [Validators.required]],
    });
  }

  private setValue(dept): void {
    this.deptCalcForm.setValue(dept);
  }

  public cancel() {
    this.ref.close();
  }

  public submit(data: FormGroup) {
    if (data.valid) {
      this.approve(data.value);
    } else {
      this.validateAllFields(data);
    }
  }

  private approve(dept): void {
    if (this.debtCalculatorService.acceptOrReject(dept)) {
      this.service = this.debtCalculatorService.createConfirm(dept).subscribe(res => {
        (res.body.code === 200) ? this.ref.close(dept) : window.alert('Cannot calculate with this payback');
      }, err => {
        window.alert('Cannot calculate with this payback');
      }, () => { });
    } else { }
  }

  public keypressEvent(event): boolean {
    if (PLACEHOLDERS.indexOf(event.target.placeholder) > -1) {
      if (event.charCode === 46 || (event.charCode > 47 && event.charCode < 58)) {
        return true;
      }
      return false;
    }
    return true;
  }

  private validateAllFields(rForm: FormGroup): void {
    Object.keys(rForm.controls).map((controlName) => {
      console.log(rForm.get(controlName));
      rForm.get(controlName).markAsTouched();
      rForm.get(controlName).markAsDirty();
    });
  }
}

