import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sndp-reduction-method',
  templateUrl: './debt-reduction-method.component.html',
  styles: [`
    :host /deep/ ul.tabset {
      justify-content: end!important;
    }`]
})
export class DebtReductionMethodComponent implements OnInit {

  constructor() { }
  selected = {
    debtReductionStrategy: false
  };
  ngOnInit() {
  }

}
