import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import {
  AuthenticatedClient,
  AuthenticatedCoach
} from '@library-core/services/auth-service/auth-service.guard';
import { UsersComponent } from './users.component';

const userRoutes: Routes = [
  {
    path: '',
    component: UsersComponent,
    children: [
      { path: '', redirectTo: 'client', pathMatch: 'full' },
      {
        path: 'client',
        loadChildren: './modules/client/client.module#ClientModule',
        canActivate: [AuthenticatedClient]
      },
      {
        path: 'coach',
        loadChildren: './modules/coach/coach.module#CoachModule',
        canActivate: [AuthenticatedCoach]
      }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(userRoutes)
  ],
  exports: [RouterModule]
})
export class UsersRoutingModule { }
