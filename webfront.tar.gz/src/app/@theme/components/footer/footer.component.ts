import { Component } from '@angular/core';

@Component({
  selector: 'ngx-footer',
  styleUrls: ['./footer.component.scss'],
  // template: `
  //   <span class="created-by">Created with ♥ by <b><a href="https://akveo.com" target="_blank">Akveo</a></b> 2017</span>
  //   <div class="socials">
  //     <a href="http://github.com/sndpkpr" target="_blank" class="ion ion-social-github"></a>
  //     <a href="http://facebook.com/sndpkpr" target="_blank" class="ion ion-social-facebook"></a>
  //     <a href="javascript:void(0)" target="_blank" class="ion ion-social-twitter"></a>
  //     <a href="javascript:void(0)" target="_blank" class="ion ion-social-linkedin"></a>
  //   </div>
  // `,
  template: `
  <span class="created-by"></span>
  <div class="socials">
    <a href="http://github.com/sndpkpr" target="_blank" class="ion ion-social-github"></a>
    <a href="http://facebook.com/sndpkpr" target="_blank" class="ion ion-social-facebook"></a>
    <a href="https://twitter.com/kaprisandeep" target="_blank" class="ion ion-social-twitter"></a>
    <a href="javascript:void(0)" target="_blank" class="ion ion-social-linkedin"></a>
  </div>
`,
})
export class FooterComponent {
}
