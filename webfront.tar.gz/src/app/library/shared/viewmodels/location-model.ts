export class LocationModel {
    ID?: string;
    LocationName?: string;
}
