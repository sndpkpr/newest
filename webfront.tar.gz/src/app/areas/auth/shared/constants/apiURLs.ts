export const AuthAPIURLs = {
    login: 'api/Auth/login',
    register: 'api/Auth/register',
    forgotPassword: 'api/Auth/forgotPassword'
};
