export const DebtCalculator = {
    currentPayback: 'api/Client/current-payback',
    createConfirm: 'api/Client/create-confirm'
};
