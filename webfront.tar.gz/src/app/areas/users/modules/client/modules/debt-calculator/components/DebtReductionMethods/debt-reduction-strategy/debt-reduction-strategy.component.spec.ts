import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtReductionStrategyComponent } from './debt-reduction-strategy.component';

describe('DebtReductionStrategyComponent', () => {
  let component: DebtReductionStrategyComponent;
  let fixture: ComponentFixture<DebtReductionStrategyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtReductionStrategyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtReductionStrategyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
