import { Component, OnInit } from '@angular/core';
import { MENU_ITEMS } from './coach-menu';

@Component({
  selector: 'app-coach',
  template: `<ngx-sample-layout>
                <nb-menu [items]="menu"></nb-menu>
                <router-outlet></router-outlet>
             </ngx-sample-layout>`,
  // styleUrls: ['./coach.component.css']
})
export class CoachComponent implements OnInit {

  menu = MENU_ITEMS;
  constructor() { }

  ngOnInit() {
  }

}
