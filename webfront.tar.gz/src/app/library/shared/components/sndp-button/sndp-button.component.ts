import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sndp-button',
  templateUrl: './sndp-button.component.html',
  styleUrls: ['./sndp-button.component.css']
})
export class SndpButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
