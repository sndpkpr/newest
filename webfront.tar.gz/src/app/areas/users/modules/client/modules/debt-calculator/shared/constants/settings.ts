import { LIST } from './compoundingList';
export const SETTINGS = {
    mode: 'inline',
    add: {
        addButtonContent: '<span><i class="nb-plus" id="add-smart-table"></i></span>',
        createButtonContent: '<i class="nb-checkmark"></i>',
        cancelButtonContent: '<i class="nb-close"></i>',
        confirmCreate: true
    },
    edit: {
        editButtonContent: '<i class="nb-edit"></i>',
        saveButtonContent: '<i class="nb-checkmark"></i>',
        cancelButtonContent: '<i class="nb-close"></i>',
        confirmSave: true
    },
    delete: {
        deleteButtonContent: '<i class="nb-trash"></i>',
        confirmDelete: true,
    },
    columns: {
        description: {
            title: 'Debt Description',
            type: 'string',
            filter: false
        },
        balance: {
            title: 'Debt Balance',
            type: 'number',
            filter: false,
            valuePrepareFunction: (value) => {
                return value === 'Total' ? value : Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
            }
        },
        minimumPaymentPercent: {
            title: 'Minimum Payment Pct',
            type: 'number',
            filter: false,
            // valuePrepareFunction: (value) => `${value.toFixed(3)}%`
        },
        minimumPaymentAmount: {
            title: 'Minimum Payment Amount',
            type: 'number',
            filter: false,
            valuePrepareFunction: (value) => {
                return value === 'Total' ? value : Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
            }
        },
        currentPayment: {
            title: 'Current Payment',
            type: 'number',
            filter: false,
            valuePrepareFunction: (value) => {
                return value === 'Total' ? value : Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
            }
        },
        interestRate: {
            title: 'Interest Rate',
            type: 'number',
            filter: false,
            // valuePrepareFunction: (value) => `${value.toFixed(3)}%`
        },
        paymentDueDay: {
            title: 'Day Due (1-31)',
            type: 'number',
            filter: false
        },
        compoundFrequency: {
            title: 'Compounding',
            type: 'html',
            filter: false,
            editor: {
                type: 'list',
                config: {
                    list: LIST,
                },
            }
        }
    },
};
