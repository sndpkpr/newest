import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualDeptComponent } from './individual-dept.component';

describe('IndividualDeptComponent', () => {
  let component: IndividualDeptComponent;
  let fixture: ComponentFixture<IndividualDeptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualDeptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualDeptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
