import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'sndp-reduction-strategy',
  templateUrl: './debt-reduction-strategy.component.html',
  styleUrls: ['./debt-reduction-strategy.component.css']
})
export class DebtReductionStrategyComponent implements OnInit {

  constructor() { }

  @Input() Selection;

  ngOnInit() {
  }

}
