export const CoachAPIURLs = {
    addClients: 'api/Coach/add-clients',
    getList: 'api/Coach/get-clientlist'
};
