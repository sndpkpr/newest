import { TestBed, async, inject } from '@angular/core/testing';

import { AuthenticatedCompany } from './auth-service.guard';
import { MembershipService, ApiService, NotificationService } from 'app/areas/admin/core/adminservice-index';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CookieModule } from 'ngx-cookie';
import { ErrorHandlerService } from 'library-core/services/error-handler/error-handler.service';
import { ToastrModule } from 'ngx-toastr';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';

describe('AuthenticatedCompany', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        CookieModule.forRoot(),
        ToastrModule.forRoot(),
        TranslateModule.forRoot(),
        RouterTestingModule
      ],
      providers: [
        AuthenticatedCompany,
        MembershipService,
        ApiService,
        ErrorHandlerService,
        NotificationService
      ]
    });
  });

  it('should be created', inject([AuthenticatedCompany], (guard: AuthenticatedCompany) => {
    expect(guard).toBeTruthy();
  }));
});
