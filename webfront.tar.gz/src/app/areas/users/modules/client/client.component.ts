import { Component, OnInit } from '@angular/core';
import { MENU_ITEMS } from './client-menu';

@Component({
  selector: 'app-client',
  template: `<ngx-sample-layout>
              <nb-menu [items]="menu"></nb-menu>
              <router-outlet></router-outlet>
             </ngx-sample-layout>`,
  // styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  menu = MENU_ITEMS;
  constructor() { }

  ngOnInit() {
  }

}
