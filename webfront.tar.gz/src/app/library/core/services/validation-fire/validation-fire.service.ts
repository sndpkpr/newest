import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ValidationFireService {

  constructor() { }

  public validateAllFields(rForm: FormGroup) {
    // console.log('validateAllFields');
    // Object.keys(rForm.controls).map((controlName) => {
    //   // tslint:disable-next-line:no-unused-expression
    //   rForm.get(controlName).markAsTouched({ onlySelf: true }) ||
    //     rForm.get(controlName).markAsDirty({ onlySelf: true });
    // });
  }
}
