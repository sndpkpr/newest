import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { MembershipService } from '@library-core/services/membership-service/membership.service';
// import { EventService } from '../../shared/service/event.service';

@Injectable()
// export class SndpResolver implements Resolve<Observable<string>> {
export class SndpResolver implements Resolve<any> {
    constructor(private membershipService: MembershipService) { }
    resolve(route: ActivatedRouteSnapshot) {
        const eventId = route.params['id'];
        const request = {
            myDataCheck: true,
            eventIdPesent: [eventId]
        };
        // return this.eventService.getEventData(request);
        return this.membershipService.isLoggedIn();
    }
}
