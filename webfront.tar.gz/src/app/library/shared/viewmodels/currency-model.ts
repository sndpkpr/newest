export class CurrencyModel {
    ID?: string;
    Symbol: string;
    CurrencyCode?: string;
}
