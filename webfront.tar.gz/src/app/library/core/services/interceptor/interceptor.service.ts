import { Injectable, Injector } from '@angular/core';
import {
  HttpClient,
  HttpRequest,
  HttpInterceptor,
  HttpHandler,
  HttpEvent,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { MembershipService } from '../membership-service/membership.service';
import { CookieService } from 'ngx-cookie';
import { tap } from 'rxjs/internal/operators';

@Injectable({
  providedIn: 'root'
})
export class SvInterceptorService implements HttpInterceptor {
  membershipservice: MembershipService;

  constructor(private cookie: CookieService) { }
  intercept(
    // tslint:disable-next-line:no-any
    req: HttpRequest<any>,
    next: HttpHandler
    // tslint:disable-next-line:no-any
  ): Observable<HttpEvent<any>> {
    if (req.body) {
      req.headers.append('Content-Type', 'application/json');
      req.headers.append('If-Modified-Since', 'Mon, 26 Jul 1997 05:00:00 GMT');
      req.headers.append('Cache-Control', 'no-cache');
      req.headers.append('Pragma', 'no-cache');
    }
    const token = this.cookie.get('token') ? this.cookie.get('token') : null;
    // const token = localStorage.getItem('token') ? localStorage.getItem('token') : null;
    if (token) {
      req = req.clone({
        setHeaders: {
          Authorization: 'Bearer ' + token
        }
      });
    }

    return next.handle(req).pipe(tap(
      // tslint:disable-next-line:no-any
      (event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          // do stuff with response if you want
        }
      },
      // tslint:disable-next-line:no-any
      (err: any) => {
        if (err instanceof HttpErrorResponse) {
        }
      }
    ));
  }
}
