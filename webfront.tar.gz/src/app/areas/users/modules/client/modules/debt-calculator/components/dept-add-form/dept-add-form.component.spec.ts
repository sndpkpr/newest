import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeptAddFormComponent } from './dept-add-form.component';

describe('DeptAddFormComponent', () => {
  let component: DeptAddFormComponent;
  let fixture: ComponentFixture<DeptAddFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeptAddFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeptAddFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
