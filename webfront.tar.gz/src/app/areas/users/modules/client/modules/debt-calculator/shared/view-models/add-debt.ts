// export interface AddDebt {
//     description: string;
//     compoundFrequency: string;
//     paymentDueDay: number;
//     minimumPaymentPercent: number;
//     balance: number;
//     interestRate: number;
//     currentPayment: number;
//     minimumPaymentAmount: number;
// }
export interface AddDebt {
    description?: string;
    compoundFrequency?: string;
    paymentDueDay?: string;
    minimumPaymentPercent?: string;
    balance?: string;
    interestRate?: string;
    currentPayment?: string;
    minimumPaymentAmount?: string;
}
