// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

// export const environment = {
//   production: false
// };

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
import { InjectionToken, Injector } from '@angular/core';
export class Environment {
  production = false;
  baseUrl = 'http://localhost:3512/';
  // baseUrl = 'http://54.71.18.74:3512/';
}

const injector = Injector.create([
  { provide: Environment, useClass: Environment, deps: [] }
]);


export const environment: Environment = injector.get(Environment);

