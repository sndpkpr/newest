import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
    {
        title: 'Home',
        icon: 'nb-e-commerce',
        link: '/coach',
        home: true,
    },
    {
        title: 'My Clients',
        icon: 'nb-person',
        children: [
            {
                title: 'Add Client ',
                icon: 'nb-plus-circled',
                link: '/coach/client/add-client'
            },
            {
                title: 'List Clients ',
                icon: 'nb-compose',
                link: '/coach/client/list-client'
            }
        ]
    }
];
