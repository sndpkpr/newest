export interface UploadImage {
  Angle?: number;
  CropperHeight?: number;
  CropperWidth?: number;
  Folder?: string;
  Height?: number;
  ImageSrc?: string;
  ImageType?: string;
  Width?: number;
  X?: number;
  Y?: number;
}

export interface UploadImageAPIData {
  angle?: number;
  scale?: number;
  h?: number;
  w?: number;
  x?: number;
  y?: number;
}

