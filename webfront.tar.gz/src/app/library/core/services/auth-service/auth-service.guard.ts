import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MembershipService } from '../membership-service/membership.service';
import { CookieService } from 'ngx-cookie';
import { GlobalConst } from '@library-core/config/constants';
import { NotificationService } from '@library-core/services/notification-service/notification.service';

// /**
//  * token not present - @return true
//  */
// @Injectable({
//   providedIn: 'root'
// })
// export class AnonymousGuard implements CanActivate {
//   constructor(private router: Router, private membershipservice: MembershipService, private cookie: CookieService) { }
//   canActivate(
//     next: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
//     if (this.membershipservice.isLoggedIn()) {
//       /**
//        * Navigate to page based on logic should be here.
//        */
//       this.router.navigate(['/']);
//       return false;
//     } else {
//       return true;
//     }
//   }
// }

// /**
//  * token present and role Client- @return true
//  */
// @Injectable({
//   providedIn: 'root'
// })
// export class AuthenticatedClient implements CanActivate {
//   constructor(private membershipservice: MembershipService, private router: Router) { }
//   canActivate(
//     next: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
//     if (this.membershipservice.isLoggedIn()) {
//       if (this.membershipservice.getLocalStorage('roleId').indexOf('4') >= 0) {
//         return true;
//       }
//     } else {
//       // navigate to login page
//       this.router.navigate(['/login']);
//       return false;
//     }
//     return true;
//   }
// }

// /**
//  * token present and role Coach- @return true
//  */
// @Injectable({
//   providedIn: 'root'
// })
// export class AuthenticatedCoach implements CanActivate {
//   constructor(private membershipservice: MembershipService, private router: Router) { }
//   canActivate(
//     next: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
//     if (this.membershipservice.isLoggedIn()) {
//       // if (this.membershipservice.getUserDetails('RoleIds').indexOf(4) >= 0) {
//       //   return true;
//       // }
//       if (this.membershipservice.getLocalStorage('roleId').indexOf('3') >= 0) {
//         return true;
//       }
//     } else {
//       // navigate to loginn page
//       this.router.navigate(['/login']);
//       return false;
//     }
//     return true;
//   }
// }

// /**
//  * token present and role Admin- @return true
//  */
// @Injectable({
//   providedIn: 'root'
// })
// export class AuthenticatedAdmin implements CanActivate {
//   constructor(private membershipservice: MembershipService, private router: Router) { }
//   canActivate(
//     next: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

//     if (this.membershipservice.isLoggedIn()) {
//       // if (this.membershipservice.getUserDetails('RoleIds').indexOf(2) >= 0) {
//       //   return true;
//       // }
//       if (this.membershipservice.getUserDetails('RoleIds').indexOf('1') >= 0) {
//         return true;
//       }
//     } else {
//       // navigate to loginn page
//       this.router.navigate(['/login']);
//       return false;
//     }
//     return true;
//   }
// }

/**
 * token not present - @return true
 */
@Injectable({
  providedIn: 'root'
})
export class AnonymousGuard implements CanActivate {
  constructor(private router: Router, private membershipservice: MembershipService, private cookie: CookieService) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.membershipservice.isLoggedIn()) {
      /**
       * Navigate to page based on logic should be here.
       */
      this.router.navigate(['/']);
      return false;
    } else {
      this.membershipservice.removeCredentials();
      return true;
    }
  }
}

/**
 * token present and role Client- @return true
 */
@Injectable({
  providedIn: 'root'
})
export class AuthenticatedClient implements CanActivate {
  constructor(private membershipservice: MembershipService, private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.membershipservice.isLoggedIn() && this.membershipservice.getLocalStorage('roleId')) {
      if (this.membershipservice.getLocalStorage('roleId').indexOf('3') >= 0) {
        return true;
      }
    } else {
      // navigate to login page
      this.membershipservice.removeCredentials();
      this.router.navigate(['/auth/login']);
      return false;
    }
    return false;
  }
}

/**
 * token present and role Coach- @return true
 */
@Injectable({
  providedIn: 'root'
})
export class AuthenticatedCoach implements CanActivate {
  constructor(private membershipservice: MembershipService, private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.membershipservice.isLoggedIn() && this.membershipservice.getLocalStorage('roleId')) {
      // if (this.membershipservice.getUserDetails('RoleIds').indexOf(4) >= 0) {
      //   return true;
      // }
      if (this.membershipservice.getLocalStorage('roleId').indexOf('2') >= 0) {
        return true;
      }
    } else {
      this.membershipservice.removeCredentials();
      // navigate to loginn page
      this.router.navigate(['/auth/login']);
      return false;
    }
    return false;
  }
}

/**
 * token present and role Admin- @return true
 */
@Injectable({
  providedIn: 'root'
})
export class AuthenticatedAdmin implements CanActivate {
  constructor(private membershipservice: MembershipService, private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    if (this.membershipservice.isLoggedIn() && this.membershipservice.getLocalStorage('roleId')) {
      // if (this.membershipservice.getUserDetails('RoleIds').indexOf(2) >= 0) {
      //   return true;
      // }
      if (this.membershipservice.getUserDetails('roleId ').indexOf('1') >= 0) {
        return true;
      }
    } else {
      // navigate to loginn page
      this.membershipservice.removeCredentials();
      this.router.navigate(['/auth/login']);
      return false;
    }
    return false;
  }
}
