import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomrenderComponent } from './customrender.component';

describe('CustomrenderComponent', () => {
  let component: CustomrenderComponent;
  let fixture: ComponentFixture<CustomrenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomrenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomrenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
