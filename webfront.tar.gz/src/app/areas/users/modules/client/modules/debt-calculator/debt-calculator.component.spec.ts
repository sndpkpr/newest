import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtCalculatorComponent } from './debt-calculator.component';

describe('DebtCalculatorComponent', () => {
  let component: DebtCalculatorComponent;
  let fixture: ComponentFixture<DebtCalculatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtCalculatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
