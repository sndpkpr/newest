import { TestBed, inject } from '@angular/core/testing';
import { ApiService } from '../api-service/api.service';
import { MembershipService } from './membership.service';
import { CookieOptions, CookieService, CookieModule, CookieOptionsProvider } from 'ngx-cookie';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ErrorHandlerService } from 'library-core/services/error-handler/error-handler.service';
import { NotificationService } from './../notification-service/notification.service';
import { ToastrModule } from 'ngx-toastr';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';

describe('MembershipService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CookieModule.forRoot(),
        HttpClientTestingModule,
        ToastrModule.forRoot(),
        TranslateModule.forRoot(),
        RouterTestingModule
      ],
      providers: [
        ApiService,
        MembershipService,
        ErrorHandlerService,
        NotificationService,
      ]
    });
  });

  it('should be created', inject([MembershipService], (service: MembershipService) => {
    expect(service).toBeTruthy();
  }));
  // Cases for Method is define or not
  it('logout is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.logout).toBeDefined();
  }));
  it('getUserByName is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.getUserByName).toBeDefined();
  }));
  it('isLoggedIn is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.isLoggedIn).toBeDefined();
  }));
  it('getToken is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.getToken).toBeDefined();
  }));
  it('setCookie is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.setCookie).toBeDefined();
  }));
  it('getCookie is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.getCookie).toBeDefined();
  }));
  it('getUserDetails is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.getUserDetails).toBeDefined();
  }));
  it('getCurrentUserObject is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.getCurrentUserObject).toBeDefined();
  }));
  it('getAllCookies is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.getAllCookies).toBeDefined();
  }));
  it('removeCredentials is defined', inject([MembershipService], (service: MembershipService) => {
    expect(service.removeCredentials).toBeDefined();
  }));
  // Cases for getUserByName
  it('should be getUserByName with parameter null', inject([MembershipService], (service: MembershipService) => {
    expect(service.getUserByName({Password: null, Token: null, Username: null})).toBeFalsy();
  }));
  it('should be getUserByName with parameter empty', inject([MembershipService], (service: MembershipService) => {
    expect(service.getUserByName({Password: '', Token: '', Username: ''})).toBeFalsy();
  }));
  it('should be getUserByName with parameter undefine', inject([MembershipService], (service: MembershipService) => {
    expect(service.getUserByName({Password: undefined, Token: undefined, Username: undefined})).toBeFalsy();
  }));
  // Cases for isLoggedIn
  it('should be isLoggedIn with login user', inject([MembershipService], (service: MembershipService) => {
    expect(service.isLoggedIn()).toBeTruthy();
  }));
  it('should be isLoggedIn with logout user', inject([MembershipService], (service: MembershipService) => {
    expect(service.isLoggedIn()).toBeFalsy();
  }));
   // Cases for getToken
   it('should be getToken without  set cookie', inject([MembershipService], (service: MembershipService) => {
    expect(service.getToken()).toBeNull();
  }));
});
