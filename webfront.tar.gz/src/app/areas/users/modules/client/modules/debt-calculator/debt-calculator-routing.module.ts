import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DebtCalculatorComponent } from './debt-calculator.component';
import { CalculatorComponent } from './components/calculator/calculator.component';

const debtCalculatorRoutes: Routes = [
  {
    path: '',
    component: DebtCalculatorComponent,
    children: [
      {
        path: '',
        component: CalculatorComponent
      }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(debtCalculatorRoutes)
  ],
  exports: [RouterModule]
})
export class DebtCalculatorRoutingModule { }
