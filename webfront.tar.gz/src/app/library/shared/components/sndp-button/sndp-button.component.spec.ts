import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SndpButtonComponent } from './sndp-button.component';

describe('SndpButtonComponent', () => {
  let component: SndpButtonComponent;
  let fixture: ComponentFixture<SndpButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SndpButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SndpButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
