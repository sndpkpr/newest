import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { CoachComponent } from './coach.component';

const coachRoutes: Routes = [
  {
    path: '',
    component: CoachComponent,
    children: [
      {
        path: '',
        redirectTo: 'client',
        pathMatch: 'full'
      },
      {
        path: 'client',
        loadChildren: './modules/clients/clients.module#ClientsModule'
      }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(coachRoutes),
  ],
  exports: [RouterModule]
})
export class CoachRoutingModule { }
