import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientsRoutingModule } from './clients-routing.module';
import { ClientComponent } from './client.component';
import { AddClientComponent } from './components/add-client/add-client.component';

import { ThemeModule } from '../../../../../../@theme/theme.module';
import { SharedModule } from '../../../../../../library/shared/shared.module';
import { ListClientComponent } from './components/list-client/list-client.component';

@NgModule({
  imports: [
    CommonModule,
    ClientsRoutingModule,
    ThemeModule,
    SharedModule
  ],
  declarations: [
    ClientComponent,
    AddClientComponent,
    ListClientComponent
  ]
})
export class ClientsModule { }
