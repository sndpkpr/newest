import { NgModule } from '@angular/core';
import { Routes, RouterModule, ExtraOptions } from '@angular/router';
import { SndpResolver } from './library/shared/resolver/sndp-resolver';
import {
  AnonymousGuard,
  AuthenticatedAdmin
} from '@library-core/services/auth-service/auth-service.guard';

import { AppComponent } from './app.component';

// const routes: Routes = [
//   {
//     path: '',
//     component: AppComponent,
//     children: [
//       {
//         path: '',
//         loadChildren: './areas/users/users.module#UsersModule'
//       },
//       {
//         path: 'pages',
//         loadChildren: 'app/pages/pages.module#PagesModule'
//       },
//       {
//         path: 'admin',
//         loadChildren: './areas/admin/admin.module#AdminModule',
//         canActivate: [AuthenticatedAdmin]
//       },
//       {
//         path: 'auth',
//         loadChildren: './areas/auth/auth.module#AuthModule',
//         canActivate: [AnonymousGuard]
//       },
//       {
//         path: 'global',
//         loadChildren: './areas/users/users.module#UsersModule',
//         resolve: { message: SndpResolver }
//       },
//     ]
//   }
// ];

const routes: Routes = [
  {
    path: 'pages',
    loadChildren: 'app/pages/pages.module#PagesModule'
  },
  {
    path: 'admin',
    loadChildren: './areas/admin/admin.module#AdminModule',
    canActivate: [AuthenticatedAdmin]
  },
  {
    path: 'auth',
    loadChildren: './areas/auth/auth.module#AuthModule',
    canActivate: [AnonymousGuard]
  },
  // {
  //   path: 'client',
  //   loadChildren: './areas/client/client.module#ClientModule',
  //   canActivate: [AuthenticatedClient]
  // },
  // {
  //   path: 'coach',
  //   loadChildren: './areas/coach/coach.module#CoachModule',
  //   canActivate: [AuthenticatedCoach]
  // },
  {
    path: 'global',
    loadChildren: './areas/users/users.module#UsersModule',
    resolve: { message: SndpResolver }
  },
  {
    path: '',
    loadChildren: './areas/users/users.module#UsersModule'
  },
];
const config: ExtraOptions = {
  useHash: true,
};

@NgModule({
  imports: [RouterModule.forRoot(routes, config)],
  exports: [RouterModule],
  providers: [SndpResolver]
})
export class AppRoutingModule { }
