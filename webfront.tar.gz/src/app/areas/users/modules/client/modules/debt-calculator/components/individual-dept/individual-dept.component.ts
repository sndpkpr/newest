import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'sndp-individual-dept',
  templateUrl: './individual-dept.component.html',
  styleUrls: ['./individual-dept.component.css']
})
export class IndividualDeptComponent implements OnInit {

  constructor() { }
  // @Input()
  // public Dept: string;
  @Input() Dept;

  ngOnInit() {
  }

}
