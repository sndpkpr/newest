export const PLACEHOLDERS = [
    'Balance',
    'Debt Balance',
    'Payment Due Day (1-31)',
    'Minimum Payment Pct',
    'Minimum Payment Percent',
    'Minimum Payment Amount',
    'Current Payment',
    'Interest Rate',
    'Day Due (1-31)'
];
