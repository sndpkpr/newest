import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoachRoutingModule } from './coach-routing.module';
import { CoachComponent } from './coach.component';
// import { UsersModule } from '../../users.module';

import { ThemeModule } from '../../../../@theme/theme.module';
// import { PagesModule } from '../../../../pages/pages.module';
import { Ng2SmartTableModule } from 'ng2-smart-table';



@NgModule({
  declarations: [CoachComponent],
  imports: [
    CommonModule,
    CoachRoutingModule,
    // UsersModule,
    ThemeModule,
    Ng2SmartTableModule
    // PagesModule
  ],
  exports: [
  ]
})
export class CoachModule {
  menu = [];
}
