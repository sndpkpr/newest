import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ClientsService } from '../../shared/services/clients.service';

@Component({
  selector: 'app-list-client',
  templateUrl: './list-client.component.html',
  styleUrls: ['./list-client.component.scss']
})
export class ListClientComponent implements OnInit {
  // ClientsList = [];
  ClientsList: { name: string, title: string }[] = [
    { name: 'Carla Espinosa', title: 'Nurse' },
    { name: 'Bob Kelso', title: 'Doctor of Medicine' },
    { name: 'Janitor', title: 'Janitor' },
    { name: 'Perry Cox', title: 'Doctor of Medicine' },
    { name: 'Ben Sullivan', title: 'Carpenter and photographer' },
  ];
  service: Subscription;

  constructor(private clientsService: ClientsService) { }

  ngOnInit() {
    this.getClientsList();
  }

  private getClientsList(): void {
    this.service = this.clientsService.getClientList({}).subscribe(
      (data) => {
        this.ClientsList = data.body.data;
      }, (error) => {
        // console.log('errror', error);i
      }
    );
  }

}
