import { TestBed } from '@angular/core/testing';

import { DebtCalculatorService } from './debt-calculator.service';

describe('DebtCalculatorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DebtCalculatorService = TestBed.get(DebtCalculatorService);
    expect(service).toBeTruthy();
  });
});
