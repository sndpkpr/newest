import { Injectable } from '@angular/core';
import { CoachAPIURLs } from '../constants';
import { ApiService } from '@library-core/services/api-service/api.service';

import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class ClientsService {

  constructor(private apiService: ApiService) { }

  addClient(data: {}): any {
    return this.apiService.postData(CoachAPIURLs.addClients, data, null);
  }

  getClientList(data: {}): any {
    // return this.apiService.postData(CoachAPIURLs.getList, data, null);
    return this.apiService.getData(CoachAPIURLs.getList, null);
  }
}
