import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client',
  template: '<router-outlet></router-outlet>',
  // styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
