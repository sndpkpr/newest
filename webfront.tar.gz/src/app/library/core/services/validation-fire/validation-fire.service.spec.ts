import { TestBed } from '@angular/core/testing';

import { ValidationFireService } from './validation-fire.service';

describe('ValidationFireService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ValidationFireService = TestBed.get(ValidationFireService);
    expect(service).toBeTruthy();
  });
});
