import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeptCalculaorComponent } from './dept-calculaor.component';

describe('DeptCalculaorComponent', () => {
  let component: DeptCalculaorComponent;
  let fixture: ComponentFixture<DeptCalculaorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeptCalculaorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeptCalculaorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
