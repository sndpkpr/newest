export interface ImageUpload {
  'public_id'?: string;
  'version'?: number;
  'signature'?: string;
  'width'?: number;
  'height'?: number;
  'format'?: string;
  'resource_type'?: string;
  'created_at'?: string;
  'bytes'?: number;
  'type'?: string;
  'etag'?: string;
  'placeholder'?: boolean;
  'url'?: string;
  'secure_url'?: string;
  'original_filename'?: string;
  'Folder'?: string;
  'ImageType'?: string;
  'ImageSrc'?: string;
  'Width'?: string;
  'Height'?: string;
  'CropperWidth'?: number;
  'CropperHeight'?: number;
  'Angle'?: number;
  'X'?: string;
  'Y'?: string;
}
