import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ClientComponent } from './client.component';
import { AddClientComponent } from './components/add-client/add-client.component';
import { ListClientComponent } from './components/list-client/list-client.component';

const clientsRoutes: Routes = [
  {
    path: '',
    component: ClientComponent,
    children: [
      { path: '', redirectTo: 'add-client', pathMatch: 'full' },
      {
        path: 'add-client',
        component: AddClientComponent
      },
      {
        path: 'list-client',
        component: ListClientComponent
      }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(clientsRoutes)
  ],
  exports: [RouterModule]
})
export class ClientsRoutingModule { }
