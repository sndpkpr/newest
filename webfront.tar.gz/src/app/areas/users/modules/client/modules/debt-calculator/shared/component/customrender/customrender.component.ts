import { Component, OnInit, Input } from '@angular/core';
// import { ViewCell } from '../view-models/view-cell';
import { ViewCell } from '../../view-models/view-cell';
@Component({
  selector: 'app-customrender',
  template: `{{renderValue}}`,
})
export class CustomrenderComponent implements ViewCell, OnInit {

  renderValue: string;

  @Input() value: string | number;
  @Input() rowData: any;

  constructor() { }

  ngOnInit() {
    this.renderValue = this.value.toString().toUpperCase();
  }

}
