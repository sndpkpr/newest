import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
// import { ValidationFireService } from '@library-core/services/validation-fire/validation-fire.service';
import { AuthService } from '../../shared/services/auth.service';
import { MembershipService } from '../../../../library/core/services/membership-service/membership.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  // providers: [AuthService]
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  service: Subscription;

  constructor(private fb: FormBuilder,
    private authService: AuthService,
    private membershipService: MembershipService,
    // private notificationservice: NotificationService,
    // private loaderService: LoaderService,
    private router: Router,
    // private route: ActivatedRoute) { }
  ) {
  }

  ngOnInit() {
    this.createForm();
  }

  private createForm(): void {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.email]],
      // password: ['', [Validators.required, Validators.pattern(this.passwordPattern)]]
      password: ['', [Validators.required]]
    });
  }

  public login(): void {
    if (this.loginForm.valid) {
      this.service = this.authService.login(this.loginForm.value).subscribe(res => {
        if (res) {
          this.redirect();
        } else {
        }
      });
    } else {
      this.validateAllFields(this.loginForm);
    }
  }

  private validateAllFields(rForm: FormGroup): void {
    Object.keys(rForm.controls).map((controlName) => {
      console.log(rForm.get(controlName));
      rForm.get(controlName).markAsTouched();
      rForm.get(controlName).markAsDirty();
      // tslint:disable-next-line:no-unused-expression
      // rForm.get(controlName).markAsTouched({ onlySelf: true }) ||
      //   rForm.get(controlName).markAsDirty({ onlySelf: true });
    });
  }

  private redirect(): void {
    const roleId = this.membershipService.getLocalStorage('roleId');
    if (roleId === '1') {
      this.router.navigate(['/admin']);
    } else if (roleId === '2') {
      this.router.navigate(['/coach']);
    } else if (roleId === '3') {
      this.router.navigate(['/client']);
    } else {
      this.redirect();
    }
  }
}
