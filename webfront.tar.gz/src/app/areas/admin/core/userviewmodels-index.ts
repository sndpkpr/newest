// library shared view-module
