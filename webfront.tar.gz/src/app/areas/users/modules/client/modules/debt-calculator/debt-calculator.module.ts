import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CalculatorComponent } from './components/calculator/calculator.component';
import { DebtCalculatorComponent } from './debt-calculator.component';

import { DebtCalculatorRoutingModule } from './debt-calculator-routing.module';

import { ThemeModule } from '../../../../../../@theme/theme.module';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CustomrenderComponent } from './shared/component/customrender/customrender.component';
import { PaybackTableComponent } from './components/payback-table/payback-table.component';
import { SharedModule } from '@library-shared/shared.module';
import { DeptAddFormComponent } from './components/dept-add-form/dept-add-form.component';
import { ShowcaseDialogComponent } from './components/showcase-dialog/showcase-dialog.component';


import { NbDialogModule, NbWindowModule } from '@nebular/theme';
import { IndividualDeptComponent } from './components/individual-dept/individual-dept.component';
import { IndividualDeptEditComponent } from './components/individual-dept-edit/individual-dept-edit.component';
import { DebtReductionMethodComponent } from './components/DebtReductionMethods/debt-reduction-method.component';
import { DebtReductionStrategyComponent } from './components/DebtReductionMethods/debt-reduction-strategy/debt-reduction-strategy.component';
import { ExtraPaymentComponent } from './components/DebtReductionMethods/extra-payment/extra-payment.component';

@NgModule({
  imports: [
    CommonModule,
    DebtCalculatorRoutingModule,
    ThemeModule,
    Ng2SmartTableModule,
    SharedModule,
    NbDialogModule.forChild(),
    NbWindowModule.forChild()
  ],
  declarations: [
    CalculatorComponent,
    DebtCalculatorComponent,
    CustomrenderComponent,
    PaybackTableComponent,
    DeptAddFormComponent,
    ShowcaseDialogComponent,
    IndividualDeptComponent,
    IndividualDeptEditComponent,
    DebtReductionMethodComponent,
    DebtReductionStrategyComponent,
    ExtraPaymentComponent
  ],
  entryComponents: [
    ShowcaseDialogComponent
  ]
})
export class DebtCalculatorModule { }
