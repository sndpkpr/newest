import { Component, TemplateRef } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { Subscription, Subject } from 'rxjs';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { DebtCalculatorService } from '../../shared/services/debt-calculator.service';
import { MomentService } from '@library-shared/services/moment/moment.service';
import { SETTINGS, PLACEHOLDERS, InitialData } from '../../shared/constants/constant-index';
import { AddDebt } from '../../shared/view-models/add-debt';
import { NbDialogService } from '@nebular/theme';
import { ShowcaseDialogComponent } from '../showcase-dialog/showcase-dialog.component';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.scss'],
})
export class CalculatorComponent {
  service: Subscription;
  currentPayback = [];
  currentTheme: string;
  settings = SETTINGS;
  source: LocalDataSource = new LocalDataSource();
  eventsSubject: Subject<void> = new Subject<void>();
  // deptArray: Array<AddDebt>;
  // deptArray: AddDebt[];
  deptArray = [];

  constructor(private fb: FormBuilder,
    private debtCalculatorService: DebtCalculatorService,
    private momentService: MomentService,
    private dialogService: NbDialogService) {
    this.testValue();
  }

  private testValue(): void { this.source.load([InitialData]); this.deptArray.push(InitialData); }

  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  public onRowSelect(event): void { this.setValueDeptCalcForm(event); }
  public createConfirm(event): void { this.confirm(event); }
  public editConfirm(event): void { this.confirm(event); }

  private confirm(event): void {
    const LoanData = event.newData;
    if (this.debtCalculatorService.acceptOrReject(LoanData)) {
      this.service = this.debtCalculatorService.createConfirm(LoanData).subscribe(res => {
        (res.body.code === 200) ? event.confirm.resolve() : event.confirm.reject(), window.alert('Cannot calculate with this payback');
      }, err => {
        window.alert('Cannot calculate with this payback');
        event.confirm.reject();
      }, () => { });
    } else {
      window.alert('Cannot calculate with this payback');
      event.confirm.reject();
    }
  }

  private setValueDeptCalcForm({ data }): void { this.eventsSubject.next(data); }

  public getAll(): void {
    const LoanContent = this.deptArray;
    this.service = this.debtCalculatorService.currentPayback(LoanContent).subscribe(res => {
      this.currentPayback = res.body.data;
    }, err => { }, () => { });
  }

  public keypressEvent(event): boolean {
    if (PLACEHOLDERS.indexOf(event.target.placeholder) > -1) {
      if (event.charCode === 46 || (event.charCode > 47 && event.charCode < 58)) {
        return true;
      }
      return false;
    }
    return true;
  }

  public onChangeTab(event): void {
    if (event.tabTitle === 'Current Payback') {
      this.getAll();
    }
  }

  public addDept(): void {
    this.dialogService.open(ShowcaseDialogComponent)
      .onClose.subscribe(data => {
        this.pushInArray(data);
      });
  }

  public editDept(dept, index): void {
    this.dialogService.open(ShowcaseDialogComponent, {
      context: { title: dept },
    }).onClose.subscribe(data => {
      if (data) {
        this.deptArray[index] = data;
      }
    });
  }

  private pushInArray(data): void {
    if (data) {
      this.deptArray.push(data);
    }
  }

  private emitEventToChild(): void { this.eventsSubject.next(); }
}

