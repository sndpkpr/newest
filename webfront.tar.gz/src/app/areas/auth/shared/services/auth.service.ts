import { Injectable } from '@angular/core';
import { AuthAPIURLs } from '../constants/apiURLs';
import { ApiService } from '../../../../library/core/services/api-service/api.service';
import { AuthModule } from '../../auth.module';
import { MembershipService } from '../../../../library/core/services/membership-service/membership.service';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private apiService: ApiService,
    private membershipService: MembershipService) { }

  // login(data: {}): any {
  //   return this.apiService.postData(AuthAPIURLs.login, data, null);
  // }

  login(body: {}) {
    // logic for login
    return this.apiService.postData(AuthAPIURLs.login, body, null)
      .pipe(map((res: any) => {
        if (res && res.body.data.token) {
          this.saveToken(res.body.data);
          this.saveUserRole(res.body.data.userData.role_id);
          return res.body.data;
        }
      }));
  }
  private saveUserRole({ roleId, roleName }) {
    this.membershipService.setLocalStorage('roleId', roleId);
    this.membershipService.setLocalStorage('roleName', roleName);
  }

  private saveToken({ token }): void {
    this.membershipService.setCookie('token', token);
  }
}
