import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-debt-calculator',
  template: '<router-outlet></router-outlet>'
})
export class DebtCalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
