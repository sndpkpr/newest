import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-deptform',
  templateUrl: './dept-add-form.component.html',
  styles: [`nb-card {  transform: translate3d(0, 0, 0); }`]
})
export class DeptAddFormComponent implements OnInit, OnDestroy {
  deptCalcForm: FormGroup;
  eventsSubscription: any;

  constructor(private fb: FormBuilder) { }
  @Input() events: Observable<void>;

  ngOnInit() {
    this.createForm();
    this.eventsSubscription = this.events.subscribe((data) => this.patchValue(data));
  }

  private createForm(): void {
    this.deptCalcForm = this.fb.group({
      description: ['', [Validators.required]],
      compoundFrequency: [''],
      paymentDueDay: ['', [Validators.required]],
      minimumPaymentPercent: [''],
      balance: [''],
      interestRate: ['', [Validators.required]],
      currentPayment: ['', [Validators.required]],
      minimumPaymentAmount: ['', [Validators.required]],
    });
  }

  private patchValue(data): void {
    this.deptCalcForm.patchValue(data);
  }

  ngOnDestroy() {
    this.eventsSubscription.unsubscribe();
  }
}
