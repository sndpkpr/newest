export class LoginModel {
    Username: string;
    Password: string;
    Token: string;
    googleCaptchaResponse: string;
    Language: string;
}
