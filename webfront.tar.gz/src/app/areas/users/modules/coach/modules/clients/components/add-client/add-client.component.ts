import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ClientsService } from '../../shared/services/clients.service';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent implements OnInit {
  addClient: FormGroup;
  service: Subscription;

  constructor(private fb: FormBuilder,
    private clientsService: ClientsService) { }

  ngOnInit() {
    this.createForm();
  }

  private createForm(): void {
    this.addClient = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      firstName: ['', [Validators.required]],
      lastName: ['']
    });
  }

  public submitForm(): void {
    if (this.addClient.valid) {
      this.addClients(this.addClient);
    } else {
      this.validateAllFields(this.addClient);
    }
  }

  private addClients({ value }): void {
    this.service = this.clientsService.addClient(value).subscribe(
      (data) => {
      }, (error) => {
        // console.log('errror', error);i
      }
    );
  }

  private validateAllFields(rForm: FormGroup): void {
    Object.keys(rForm.controls).map((controlName) => {
      rForm.get(controlName).markAsTouched();
      rForm.get(controlName).markAsDirty();
      // tslint:disable-next-line:no-unused-expression
      // rForm.get(controlName).markAsTouched({ onlySelf: true }) ||
      //   rForm.get(controlName).markAsDirty({ onlySelf: true });
    });
  }
}
