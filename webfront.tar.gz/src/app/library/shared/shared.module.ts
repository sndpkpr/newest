import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ToastrModule } from 'ngx-toastr';
import { ReactiveFormsModule } from '@angular/forms';

import { ValidationsComponent } from './components/validations/validations.component';
import { SndpButtonComponent } from './components/sndp-button/sndp-button.component';
import { GlobalFooterComponent } from './components/global-footer/global-footer.component';
import { GlobalHeaderComponent } from './components/global-header/global-header.component';

import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [ValidationsComponent, SndpButtonComponent, GlobalFooterComponent, GlobalHeaderComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    ToastrModule.forRoot()
  ],
  exports: [
    ValidationsComponent,
    SndpButtonComponent,
    ReactiveFormsModule,
    ToastrModule,
    RouterModule
  ]
})
export class SharedModule { }
