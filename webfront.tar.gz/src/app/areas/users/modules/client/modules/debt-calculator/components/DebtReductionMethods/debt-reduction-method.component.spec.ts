import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtReductionMethodComponent } from './debt-reduction-method.component';

describe('DebtReductionMethodComponent', () => {
  let component: DebtReductionMethodComponent;
  let fixture: ComponentFixture<DebtReductionMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtReductionMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtReductionMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
