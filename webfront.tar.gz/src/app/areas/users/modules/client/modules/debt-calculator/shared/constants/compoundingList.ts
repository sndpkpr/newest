export const LIST = [
    // { value: 'Continuous', title: 'Continuous' },
    // { value: 'Daily', title: 'Daily' },
    // { value: 'Weekly', title: 'Weekly' },
    // { value: 'Twice Monthly', title: 'Twice Monthly' },
    // { value: 'Every 4 Weeks', title: 'Every 4 Weeks' },
    { value: 'Monthly', title: 'Monthly' },
    // { value: 'Bimonthy', title: 'Bimonthy' },
    // { value: 'Quarterly', title: 'Quarterly' },
    // { value: 'Every 4 Months', title: 'Every 4 Months' },
    // { value: 'Semiannually', title: 'Semiannually' },
    // { value: 'Annually', title: 'Annually' },
    // { value: 'Exact', title: 'Exact' }
];
